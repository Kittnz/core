UPDATE `quest_template` SET `RequiredRaces` = '513' WHERE (`entry` = '1641') and (`patch` = '0');
