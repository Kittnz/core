REPLACE INTO creature_model_info VALUES 

(18000, 5875, 2, 2, 0, 0, 0),
(18001, 5875, 2, 2, 0, 0, 0),
(18002, 5875, 2, 2, 0, 0, 0),
(18003, 5875, 2, 2, 0, 0, 0),
(18004, 5875, 2, 2, 0, 0, 0),
(18005, 5875, 2, 2, 0, 0, 0),
(18006, 5875, 2, 2, 0, 0, 0),
(18007, 5875, 2, 2, 0, 0, 0),
(18008, 5875, 2, 2, 0, 0, 0),
(18009, 5875, 2, 2, 0, 0, 0),
(18010, 5875, 2, 2, 0, 0, 0),
(18011, 5875, 2, 2, 0, 0, 0),
(18012, 5875, 2, 2, 0, 0, 0),
(18013, 5875, 2, 2, 0, 0, 0),
(18014, 5875, 2, 2, 0, 0, 0),
(18015, 5875, 2, 2, 0, 0, 0),
(18016, 5875, 2, 2, 0, 0, 0),
(18017, 5875, 2, 2, 0, 0, 0),
(18018, 5875, 2, 2, 0, 0, 0),
(18019, 5875, 2, 2, 0, 0, 0),
(18020, 5875, 2, 2, 0, 0, 0),
(18021, 5875, 2, 2, 0, 0, 0),
(18022, 5875, 2, 2, 0, 0, 0),
(18023, 5875, 2, 2, 0, 0, 0),
(18024, 5875, 2, 2, 0, 0, 0),
(18025, 5875, 2, 2, 0, 0, 0),
(18026, 5875, 2, 2, 0, 0, 0),
(18027, 5875, 2, 2, 0, 0, 0),
(18028, 5875, 2, 2, 0, 0, 0),
(18029, 5875, 2, 2, 0, 0, 0),
(18030, 5875, 2, 2, 0, 0, 0),
(18031, 5875, 2, 2, 0, 0, 0),
(18032, 5875, 2, 2, 0, 0, 0),
(18033, 5875, 2, 2, 0, 0, 0),
(18034, 5875, 2, 2, 0, 0, 0),
(18035, 5875, 2, 2, 0, 0, 0),
(18036, 5875, 2, 2, 0, 0, 0),
(18037, 5875, 2, 2, 0, 0, 0),
(18038, 5875, 2, 2, 0, 0, 0),
(18039, 5875, 2, 2, 0, 0, 0),
(18040, 5875, 2, 2, 0, 0, 0),
(18041, 5875, 2, 2, 0, 0, 0),
(18042, 5875, 2, 2, 0, 0, 0),
(18043, 5875, 2, 2, 0, 0, 0),
(18044, 5875, 2, 2, 0, 0, 0),
(18045, 5875, 2, 2, 0, 0, 0),
(18046, 5875, 2, 2, 0, 0, 0),
(18047, 5875, 2, 2, 0, 0, 0),
(18048, 5875, 2, 2, 0, 0, 0),
(18049, 5875, 2, 2, 0, 0, 0),
(18050, 5875, 2, 2, 0, 0, 0),
(18051, 5875, 2, 2, 0, 0, 0),
(18052, 5875, 2, 2, 0, 0, 0),
(18053, 5875, 2, 2, 0, 0, 0),
(18054, 5875, 2, 2, 0, 0, 0),
(18055, 5875, 2, 2, 0, 0, 0),
(18056, 5875, 2, 2, 0, 0, 0),
(18057, 5875, 2, 2, 0, 0, 0),
(18058, 5875, 2, 2, 0, 0, 0),
(18059, 5875, 2, 2, 0, 0, 0),
(18060, 5875, 2, 2, 0, 0, 0),
(18061, 5875, 2, 2, 0, 0, 0),
(18062, 5875, 2, 2, 0, 0, 0),
(18063, 5875, 2, 2, 0, 0, 0),
(18064, 5875, 2, 2, 0, 0, 0),
(18065, 5875, 2, 2, 0, 0, 0),
(18066, 5875, 2, 2, 0, 0, 0),
(18067, 5875, 2, 2, 0, 0, 0),
(18068, 5875, 2, 2, 0, 0, 0),
(18069, 5875, 2, 2, 0, 0, 0),
(18070, 5875, 2, 2, 0, 0, 0),
(18071, 5875, 2, 2, 0, 0, 0),
(18072, 5875, 2, 2, 0, 0, 0),
(18073, 5875, 2, 2, 0, 0, 0),
(18074, 5875, 2, 2, 0, 0, 0),
(18075, 5875, 2, 2, 0, 0, 0),
(18076, 5875, 2, 2, 0, 0, 0),
(18077, 5875, 2, 2, 0, 0, 0),
(18078, 5875, 2, 2, 0, 0, 0),
(18079, 5875, 2, 2, 0, 0, 0),
(18080, 5875, 2, 2, 0, 0, 0),
(18081, 5875, 2, 2, 0, 0, 0),
(18082, 5875, 2, 2, 0, 0, 0),
(18083, 5875, 2, 2, 0, 0, 0),
(18084, 5875, 2, 2, 0, 0, 0),
(18085, 5875, 2, 2, 0, 0, 0),
(18086, 5875, 2, 2, 0, 0, 0),
(18087, 5875, 2, 2, 0, 0, 0),
(18088, 5875, 2, 2, 0, 0, 0),
(18089, 5875, 2, 2, 0, 0, 0),
(18090, 5875, 2, 2, 0, 0, 0),
(18091, 5875, 2, 2, 0, 0, 0),
(18092, 5875, 2, 2, 0, 0, 0),
(18093, 5875, 2, 2, 0, 0, 0),
(18094, 5875, 2, 2, 0, 0, 0),
(18095, 5875, 2, 2, 0, 0, 0),
(18096, 5875, 2, 2, 0, 0, 0),
(18097, 5875, 2, 2, 0, 0, 0),
(18098, 5875, 2, 2, 0, 0, 0),
(18099, 5875, 2, 2, 0, 0, 0),
(18100, 5875, 2, 2, 0, 0, 0),
(18101, 5875, 2, 2, 0, 0, 0),
(18102, 5875, 2, 2, 0, 0, 0),
(18103, 5875, 2, 2, 0, 0, 0),
(18104, 5875, 2, 2, 0, 0, 0),
(18105, 5875, 2, 2, 0, 0, 0),
(18106, 5875, 2, 2, 0, 0, 0),
(18107, 5875, 2, 2, 0, 0, 0),
(18108, 5875, 2, 2, 0, 0, 0),
(18109, 5875, 2, 2, 0, 0, 0),
(18110, 5875, 2, 2, 0, 0, 0),
(18111, 5875, 2, 2, 0, 0, 0),
(18112, 5875, 2, 2, 0, 0, 0),
(18113, 5875, 2, 2, 0, 0, 0),
(18114, 5875, 2, 2, 0, 0, 0),
(18115, 5875, 2, 2, 0, 0, 0),
(18116, 5875, 2, 2, 0, 0, 0),
(18117, 5875, 2, 2, 0, 0, 0),
(18118, 5875, 2, 2, 0, 0, 0),
(18119, 5875, 2, 2, 0, 0, 0),
(18120, 5875, 2, 2, 0, 0, 0),
(18121, 5875, 2, 2, 0, 0, 0),
(18122, 5875, 2, 2, 0, 0, 0),
(18123, 5875, 2, 2, 0, 0, 0),
(18124, 5875, 2, 2, 0, 0, 0),
(18125, 5875, 2, 2, 0, 0, 0),
(18126, 5875, 2, 2, 0, 0, 0),
(18127, 5875, 2, 2, 0, 0, 0),
(18128, 5875, 2, 2, 0, 0, 0),
(18129, 5875, 2, 2, 0, 0, 0),
(18130, 5875, 2, 2, 0, 0, 0),
(18131, 5875, 2, 2, 0, 0, 0),
(18132, 5875, 2, 2, 0, 0, 0),
(18133, 5875, 2, 2, 0, 0, 0),
(18134, 5875, 2, 2, 0, 0, 0),
(18135, 5875, 2, 2, 0, 0, 0),
(18136, 5875, 2, 2, 0, 0, 0),
(18137, 5875, 2, 2, 0, 0, 0),
(18138, 5875, 2, 2, 0, 0, 0),
(18139, 5875, 2, 2, 0, 0, 0),
(18140, 5875, 2, 2, 0, 0, 0),
(18141, 5875, 2, 2, 0, 0, 0),
(18142, 5875, 2, 2, 0, 0, 0),
(18143, 5875, 2, 2, 0, 0, 0),
(18144, 5875, 2, 2, 0, 0, 0),
(18145, 5875, 2, 2, 0, 0, 0),
(18146, 5875, 2, 2, 0, 0, 0),
(18147, 5875, 2, 2, 0, 0, 0),
(18148, 5875, 2, 2, 0, 0, 0),
(18149, 5875, 2, 2, 0, 0, 0),
(18150, 5875, 2, 2, 0, 0, 0),
(18151, 5875, 2, 2, 0, 0, 0),
(18152, 5875, 2, 2, 0, 0, 0),
(18153, 5875, 2, 2, 0, 0, 0),
(18154, 5875, 2, 2, 0, 0, 0),
(18155, 5875, 2, 2, 0, 0, 0),
(18156, 5875, 2, 2, 0, 0, 0),
(18157, 5875, 2, 2, 0, 0, 0),
(18158, 5875, 2, 2, 0, 0, 0),
(18159, 5875, 2, 2, 0, 0, 0),
(18160, 5875, 2, 2, 0, 0, 0),
(18161, 5875, 2, 2, 0, 0, 0),
(18162, 5875, 2, 2, 0, 0, 0),
(18163, 5875, 2, 2, 0, 0, 0),
(18164, 5875, 2, 2, 0, 0, 0),
(18165, 5875, 2, 2, 0, 0, 0),
(18166, 5875, 2, 2, 0, 0, 0),
(18167, 5875, 2, 2, 0, 0, 0),
(18168, 5875, 2, 2, 0, 0, 0),
(18169, 5875, 2, 2, 0, 0, 0),
(18170, 5875, 2, 2, 0, 0, 0),
(18171, 5875, 2, 2, 0, 0, 0),
(18172, 5875, 2, 2, 0, 0, 0),
(18173, 5875, 2, 2, 0, 0, 0),
(18174, 5875, 2, 2, 0, 0, 0),
(18175, 5875, 2, 2, 0, 0, 0),
(18176, 5875, 2, 2, 0, 0, 0),
(18177, 5875, 2, 2, 0, 0, 0),
(18178, 5875, 2, 2, 0, 0, 0),
(18179, 5875, 2, 2, 0, 0, 0),
(18180, 5875, 2, 2, 0, 0, 0),
(18181, 5875, 2, 2, 0, 0, 0),
(18182, 5875, 2, 2, 0, 0, 0),
(18183, 5875, 2, 2, 0, 0, 0),
(18184, 5875, 2, 2, 0, 0, 0),
(18185, 5875, 2, 2, 0, 0, 0),
(18186, 5875, 2, 2, 0, 0, 0),
(18187, 5875, 2, 2, 0, 0, 0),
(18188, 5875, 2, 2, 0, 0, 0),
(18189, 5875, 2, 2, 0, 0, 0),
(18190, 5875, 2, 2, 0, 0, 0),
(18191, 5875, 2, 2, 0, 0, 0),
(18192, 5875, 2, 2, 0, 0, 0),
(18193, 5875, 2, 2, 0, 0, 0),
(18194, 5875, 2, 2, 0, 0, 0),
(18195, 5875, 2, 2, 0, 0, 0),
(18196, 5875, 2, 2, 0, 0, 0),
(18197, 5875, 2, 2, 0, 0, 0),
(18198, 5875, 2, 2, 0, 0, 0),
(18199, 5875, 2, 2, 0, 0, 0),
(18200, 5875, 2, 2, 0, 0, 0),
(18201, 5875, 2, 2, 0, 0, 0),
(18202, 5875, 2, 2, 0, 0, 0),
(18203, 5875, 2, 2, 0, 0, 0),
(18204, 5875, 2, 2, 0, 0, 0),
(18205, 5875, 2, 2, 0, 0, 0),
(18206, 5875, 2, 2, 0, 0, 0),
(18207, 5875, 2, 2, 0, 0, 0),
(18208, 5875, 2, 2, 0, 0, 0),
(18209, 5875, 2, 2, 0, 0, 0),
(18210, 5875, 2, 2, 0, 0, 0),
(18211, 5875, 2, 2, 0, 0, 0),
(18212, 5875, 2, 2, 0, 0, 0),
(18213, 5875, 2, 2, 0, 0, 0),
(18214, 5875, 2, 2, 0, 0, 0),
(18215, 5875, 2, 2, 0, 0, 0),
(18216, 5875, 2, 2, 0, 0, 0),
(18217, 5875, 2, 2, 0, 0, 0),
(18218, 5875, 2, 2, 0, 0, 0),
(18219, 5875, 2, 2, 0, 0, 0),
(18220, 5875, 2, 2, 0, 0, 0),
(18221, 5875, 2, 2, 0, 0, 0),
(18222, 5875, 2, 2, 0, 0, 0),
(18223, 5875, 2, 2, 0, 0, 0),
(18224, 5875, 2, 2, 0, 0, 0),
(18225, 5875, 2, 2, 0, 0, 0),
(18226, 5875, 2, 2, 0, 0, 0),
(18227, 5875, 2, 2, 0, 0, 0),
(18228, 5875, 2, 2, 0, 0, 0),
(18229, 5875, 2, 2, 0, 0, 0),
(18230, 5875, 2, 2, 0, 0, 0),
(18231, 5875, 2, 2, 0, 0, 0),
(18232, 5875, 2, 2, 0, 0, 0),
(18233, 5875, 2, 2, 0, 0, 0),
(18234, 5875, 2, 2, 0, 0, 0),
(18235, 5875, 2, 2, 0, 0, 0),
(19000, 5875, 2, 2, 0, 0, 0),
(19001, 5875, 2, 2, 0, 0, 0),
(19002, 5875, 2, 2, 0, 0, 0),
(19003, 5875, 2, 2, 0, 0, 0),
(19004, 5875, 2, 2, 0, 0, 0),
(19005, 5875, 2, 2, 0, 0, 0),
(19006, 5875, 2, 2, 0, 0, 0),
(19007, 5875, 2, 2, 0, 0, 0),
(19008, 5875, 2, 2, 0, 0, 0),
(19009, 5875, 2, 2, 0, 0, 0),
(19010, 5875, 2, 2, 0, 0, 0),
(19011, 5875, 2, 2, 0, 0, 0),
(19012, 5875, 2, 2, 0, 0, 0),
(19013, 5875, 2, 2, 0, 0, 0),
(19014, 5875, 2, 2, 0, 0, 0),
(19015, 5875, 2, 2, 0, 0, 0),
(19016, 5875, 2, 2, 0, 0, 0),
(19017, 5875, 2, 2, 0, 0, 0),
(19018, 5875, 2, 2, 0, 0, 0),
(19019, 5875, 2, 2, 0, 0, 0),
(19020, 5875, 2, 2, 0, 0, 0),
(19021, 5875, 2, 2, 0, 0, 0),
(19022, 5875, 2, 2, 1, 0, 0);

replace into item_template values

('40000', '0', '0', '0', 'Tomato', '', '1297', '1', '0', '1', '0', '0', '0', '-1', '-1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0','0', '0','0', '0', '0', '0', '0', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', NULL),
('30817', '0', '0', '0', 'Simple Flour', '', '22979', '1', '0', '1', '0', '0', '0', '-1', '-1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0','0', '0','0', '0', '0', '0', '0', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', NULL);

update map_template set map_type = 0 where entry = 169;
update map_template set map_type = 0 where entry = 169;

replace into map_template (entry, map_type, level_min, player_limit, map_name) VALUES (532, 1, 60, 25, 'Karazhan');

replace into creature_template (entry, display_id1, name, subname, level_min, level_max, health_min, health_max, faction, script_name, scale) values
(6029, 4729, 'Test Morph #1', '', 1, 1, 64, 64, 35, '', 1),
(6036, 18043, 'Test Morph #1', '', 1, 1, 64, 64, 35, '', 1),
(40000, 18177, 'Fox Kit', '', 1, 1, 64, 64, 35, '', 1),
(40001, 18143, 'Spectral Tiger ', '', 1, 1, 64, 64, 35, '', 1),
(40002, 10034, 'Dryad', '', 1, 1, 64, 64, 35, '', 1),
(40003, 150, 'Keeper of the Grove', '', 1, 1, 64, 64, 35, '', 1),
(40004, 18008, 'Fox', '', 1, 1, 64, 64, 35, '', 1),
(40005, 18094, 'Swift Rooster', '', 1, 1, 64, 64, 35, '', 1),
(40006, 18093, 'White Riding Bear', '', 1, 1, 64, 64, 35, '', 1),
(40007, 18085, 'Black Riding Bear', '', 1, 1, 64, 64, 35, '', 1),
(40008, 18089, 'Ash Riding Bear', '', 1, 1, 64, 64, 35, '', 1),
(40009, 18091, 'Dark Brown Riding Bear', '', 1, 1, 64, 64, 35, '', 1),
(40010, 18092, 'Snowy Riding Bear', '', 1, 1, 64, 64, 35, '', 1),
(40011, 18090, 'Brown Riding Bear', '', 1, 1, 64, 64, 35, '', 1),
(40012, 18073, 'Enchanted Broom', '', 1, 1, 64, 64, 35, '', 1),
(40013, 18176, 'Thalassian Tender', '', 1, 1, 64, 64, 35, '', 1),
(40014, 18178, 'Dryad Fawn', '', 1, 1, 64, 64, 35, '', 1),
(40015, 18167, 'Thalassian Warhorse', '', 1, 1, 64, 64, 35, '', 1),
(40016, 18168, 'Argent Warhorse', '', 1, 1, 64, 64, 35, '', 1),
(40017, 18169, 'Thalassian Charger', '', 1, 1, 64, 64, 35, '', 1),
(40018, 18170, 'Argent Charger ', '', 1, 1, 64, 64, 35, '', 1),
(40019, 18175, 'Dragonhawk Hatchling', '', 1, 1, 64, 64, 35, '', 1),
(40020, 18003, 'Thalassian Child', '', 1, 1, 64, 64, 35, '', 1),
(40021, 18098, 'Cheeky Monkey', '', 1, 1, 64, 64, 35, '', 1),
(41000, 19000, 'Tamamo', '', 1, 1, 64, 64, 35, '', 1);

-- New quests

 replace into item_template values
 ('51877', '0', '4', '3', 'Copper Scale Leggings', '', '13095', '1', '0', '1', '15', '15', '7', '-1', '-1', '5',
 '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0',
 '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0',
 '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '58', '0', '0', '0',
 '0', '0', '0', '0', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0', '-1', '0', '0',
 '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0',
 '-1', '1', '0', '0', '0', '0', '0', '5', '0', '0', '0', '40', '0', '0', '0', '0', '0', '0', '0', '0',
 '0', '1', NULL);
 
 replace into item_template values
 ('51876', '0', '4', '2', 'Wolfskin Boots', '', '16802', '1', '0', '1', '15', '15', '8', '-1', '-1', '5',
 '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0',
 '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0',
 '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '23', '0', '0', '0',
 '0', '0', '0', '0', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0', '-1', '0', '0',
 '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0',
 '-1', '1', '0', '0', '0', '0', '0', '8', '0', '0', '0', '20', '0', '0', '0', '0', '0', '0', '0', '0',
 '0', '1', NULL);
 
 replace into item_template values
 ('51875', '0', '4', '1', 'Tapered Belt', '', '16832', '1', '0', '1', '15', '15', '6', '-1', '-1', '5',
 '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0',
 '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0',
 '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '6', '0', '0', '0',
 '0', '0', '0', '0', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0', '-1', '0', '0',
 '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0',
 '-1', '1', '0', '0', '0', '0', '0', '7', '0', '0', '0', '14', '0', '0', '0', '0', '0', '0', '0', '0',
 '0', '1', NULL);
 
REPLACE INTO `creature_template` VALUES (51600, 0, 365, 0, 0, 0, 'Snufflesnout', '', 0, 4, 5, 165, 185, 0, 0, 72, 25, 0, 1, 0.857143, 1.2, 20, 5, 0, 0, 1, 3, 5, 0, 60, 1, 2000, 2000, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 80, 80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 8, 'EventAI', 1, 1, 0, 0, 3, 80, 0, 0, 0, 0, 2, '');

replace into quest_template (
entry, patch, Method, ZoneOrSort, MinLevel, QuestLevel, MaxLevel, Type, RequiredClasses, RequiredRaces, RequiredSkill,
RequiredSkillValue, RepObjectiveFaction, RepObjectiveValue, RequiredMinRepFaction, RequiredMinRepValue,RequiredMaxRepFaction,
RequiredMaxRepValue, SuggestedPlayers, LimitTime, QuestFlags, SpecialFlags, PrevQuestId, NextQuestId, ExclusiveGroup, NextQuestInChain,
SrcItemId, SrcItemCount, SrcSpell, Title, Details, Objectives, OfferRewardText, RequestItemsText, EndText, ObjectiveText1, ObjectiveText2,
ObjectiveText3, ObjectiveText4, ReqItemId1, ReqItemId2, ReqItemId3, ReqItemId4, ReqItemCount1, ReqItemCount2, ReqItemCount3,
ReqItemCount4, ReqSourceId1, ReqSourceId2, ReqSourceId3, ReqSourceId4, ReqSourceCount1, ReqSourceCount2, ReqSourceCount3,
ReqSourceCount4, ReqCreatureOrGOId1, ReqCreatureOrGOId2, ReqCreatureOrGOId3, ReqCreatureOrGOId4, ReqCreatureOrGOCount1,
ReqCreatureOrGOCount2, ReqCreatureOrGOCount3, ReqCreatureOrGOCount4, ReqSpellCast1, ReqSpellCast2, ReqSpellCast3,
ReqSpellCast4, RewChoiceItemId1, RewChoiceItemId2, RewChoiceItemId3, RewChoiceItemId4, RewChoiceItemId5, RewChoiceItemId6,
RewChoiceItemCount1, RewChoiceItemCount2, RewChoiceItemCount3, RewChoiceItemCount4, RewChoiceItemCount5, RewChoiceItemCount6,
RewItemId1, RewItemId2, RewItemId3, RewItemId4, RewItemCount1, RewItemCount2, RewItemCount3, RewItemCount4, RewRepFaction1,
RewRepFaction2, RewRepFaction3, RewRepFaction4, RewRepFaction5, RewRepValue1, RewRepValue2, RewRepValue3, RewRepValue4,
RewRepValue5, RewOrReqMoney, RewMoneyMaxLevel, RewSpell, RewSpellCast, RewMailTemplateId, RewMailMoney, RewMailDelaySecs,
PointMapId, PointX, PointY, PointOpt, DetailsEmote1, DetailsEmote2, DetailsEmote3, DetailsEmote4, DetailsEmoteDelay1,
DetailsEmoteDelay2, DetailsEmoteDelay3, DetailsEmoteDelay4, IncompleteEmote, CompleteEmote, OfferRewardEmote1, OfferRewardEmote2,
OfferRewardEmote3, OfferRewardEmote4, OfferRewardEmoteDelay1, OfferRewardEmoteDelay2, OfferRewardEmoteDelay3,OfferRewardEmoteDelay4,
StartScript, CompleteScript)
         values
 ('60145', '0', '2', '24', '1', '5', '60', '0', '0', '0', '0',
'0', '0', '0', '0', '0','0',
'0', '0', '0', '0', '0', '15', '0', '0', '0',
'0', '0', '0', 'Down in the Ridge', 'Kill Snufflesnout, then report back to Marshal McBride in Northshire Abbey.', 'We also got reports of a kobold much larger than the others, hiding deep in the Echo Ridge. Even it\'s mere existence poses a threat to the abbey.\n\nGo down into the Echo Ridge and kill it. You will be justly rewarded.', 'Even though your journey just begun, you\'re already accomplishing great things. Take one, you earned it.', 'I assume you killed the beast?', '', '', '',
'', '', '0', '0', '0', '0', '0', '0', '0',
'0', '0', '0', '0', '0', '0', '0', '0',
'0', '51600', '0', '0', '0', '1',
'0', '0', '0', '0', '0', '0',
'0', '51875', '51876', '51877', '0', '0', '0',
'1', '1', '1', '0', '0', '0',
'0', '0', '0', '0', '0', '0', '0', '0', '72',
'0', '0', '0', '0', '100', '0', '0', '0',
'0', '0', '200', '0', '0', '0', '0', '0',
'0', '0', '0', '0', '0', '0', '0', '0', '0',
'0', '0', '0', '0', '0', '0', '0',
'0', '0', '0', '0', '0','0',
0, 0);
replace into creature_questrelation (id, quest, patch_min, patch_max) values ('197','60145','10','10');
replace into creature_involvedrelation (id, quest, patch_min, patch_max) values ('197','60145','10','10');
      
-- Fix potion stucks.

update item_template set stackable = 10 where entry in (

3387,
13458,
5634,
13443,
3823,
13455,
9172,
6048,
6052,
13461,
9030,
13459,
3386,
13457,
13442,
2459,
20008,
929,
6372,
3928,
1710,
13456,
6149,
13462,
3827,
5633,
18253,
6049,
118,
2456,
6050,
4596,
20002,
858,
12190,
5631,
3385,
2455,
9144,
4623,
8956,
9036,
13506,
13510,
13512,
13511,
13513,
20007,
13454,
13452,
21546,
3825,
9088,
9206,
9264,
6373,
3388,
9187,
13445,
9155,
6662,
8827,
13447,
17708,
20004,
3389,
13453,
5996,
9197,
8949,
9179,
9154,
8951,
10592,
9224,
2457,
3383,
3391,
2458,
3390,
3826,
18294,
3828,
2454,
9233,
3382,
5997,
3012,
1477,
4425,
10309,
955,
2290,
4419,
10308,
1180,
1711,
4422,
10307,
1181,
1712,
4424,
10306,
954,
2289,
4426,
10310,
3013,
1478,
4421,
10305);

-- repair bot

replace into  `npc_vendor` (`entry`, `item`) VALUES ('50041', '5140');

-- New quests

replace into quest_template values
('60147', '0', '2', '363', '4', '4', '0', '0', '0', '0', '0',
'0', '0', '0', '0', '0', '0',
'0', '0', '0', '0', '0', '0', '0', '0', '0',
'0', '0', '0', 'Stalking the Felstalkers', 'You\'ve fought the vile familiars outside the coven, but the taint in the valley trails deeper.\n\nYou must go inside the coven and slay the felstalkers. Return and you\'ll be rewarded.', 'Kill 10 Felstalkers. Return to Zureetha Fargaze outside the Den.', 'You have struck a blow to their numbers, and returned in one piece.\n\nTake one, you earned it.', 'What are you waiting for?', '', '', '',
'', '', '0', '0', '0', '0', '0', '0', '0',
'0', '0', '0', '0', '0', '0', '0', '0',
'0', '3102', '0', '0', '0', '10',
'0', '0', '0', '0', '0', '0',
'0', '51880', '51881', '51882', '0', '0', '0',
'1', '1', '1', '0', '0', '0',
'0', '0', '0', '0', '0', '0', '0', '0', '76',
'530', '0', '0', '0', '100', '100', '0', '0',
'0', '0', '150', '0', '0', '0', '0', '0',
'0', '0', '0', '0', '0', '0', '0', '0', '0',
'0', '0', '0', '0', '0', '0', '0',
'0', '0', '0', '0', '0','0',
0, 0);
replace into creature_questrelation (id, quest, patch_min, patch_max) values ('3145','60147','10','10');
replace into creature_involvedrelation (id, quest, patch_min, patch_max) values ('3145','60147','10','10');

update quest_template set PrevQuestId = 792 where entry = 60147;

UPDATE `quest_template` SET `MaxLevel`='0' WHERE (`entry`='60147') AND (`patch`='0');
UPDATE `quest_template` SET questlevel = 4 WHERE (`entry`='60147') AND (`patch`='0');
      
 replace into item_template values
 ('51880', '0', '4', '1', 'Grunt\'s Belt', '', '9903', '1', '0', '1', '15', '15', '6', '-1', '-1', '5',
 '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0',
 '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0',
 '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '6', '0', '0', '0',
 '0', '0', '0', '0', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0', '-1', '0', '0',
 '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0',
 '-1', '1', '0', '0', '0', '0', '0', '7', '0', '0', '0', '14', '0', '0', '0', '0', '0', '0', '0', '0',
 '0', '1', NULL);
 
 replace into item_template values
 ('51881', '0', '4', '3', 'Hardlink Boots', '', '6903', '1', '0', '1', '18', '18', '8', '-1', '-1', '9',
 '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0',
 '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0',
 '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '65', '0', '0', '0',
 '0', '0', '0', '0', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0', '-1', '0', '0',
 '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0',
 '-1', '1', '0', '0', '0', '0', '0', '5', '0', '0', '0', '30', '0', '0', '0', '0', '0', '0', '0', '0',
 '0', '1', NULL);
 
 replace into item_template values
 ('51882', '0', '4', '2', 'Demon Skin Boots', '', '7537', '1', '0', '1', '18', '18', '8', '-1', '-1', '9',
 '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0',
 '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0',
 '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '34', '0', '0', '0',
 '0', '0', '0', '0', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0', '-1', '0', '0',
 '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0',
 '-1', '1', '0', '0', '0', '0', '0', '8', '0', '0', '0', '25', '0', '0', '0', '0', '0', '0', '0', '0',
 '0', '1', NULL);
 
-- Broodmother
 
replace into quest_template (
entry, patch, Method, ZoneOrSort, MinLevel, QuestLevel, MaxLevel, Type, RequiredClasses, RequiredRaces, RequiredSkill,
RequiredSkillValue, RepObjectiveFaction, RepObjectiveValue, RequiredMinRepFaction, RequiredMinRepValue,RequiredMaxRepFaction,
RequiredMaxRepValue, SuggestedPlayers, LimitTime, QuestFlags, SpecialFlags, PrevQuestId, NextQuestId, ExclusiveGroup, NextQuestInChain,
SrcItemId, SrcItemCount, SrcSpell, Title, Details, Objectives, OfferRewardText, RequestItemsText, EndText, ObjectiveText1, ObjectiveText2,
ObjectiveText3, ObjectiveText4, ReqItemId1, ReqItemId2, ReqItemId3, ReqItemId4, ReqItemCount1, ReqItemCount2, ReqItemCount3,
ReqItemCount4, ReqSourceId1, ReqSourceId2, ReqSourceId3, ReqSourceId4, ReqSourceCount1, ReqSourceCount2, ReqSourceCount3,
ReqSourceCount4, ReqCreatureOrGOId1, ReqCreatureOrGOId2, ReqCreatureOrGOId3, ReqCreatureOrGOId4, ReqCreatureOrGOCount1,
ReqCreatureOrGOCount2, ReqCreatureOrGOCount3, ReqCreatureOrGOCount4, ReqSpellCast1, ReqSpellCast2, ReqSpellCast3,
ReqSpellCast4, RewChoiceItemId1, RewChoiceItemId2, RewChoiceItemId3, RewChoiceItemId4, RewChoiceItemId5, RewChoiceItemId6,
RewChoiceItemCount1, RewChoiceItemCount2, RewChoiceItemCount3, RewChoiceItemCount4, RewChoiceItemCount5, RewChoiceItemCount6,
RewItemId1, RewItemId2, RewItemId3, RewItemId4, RewItemCount1, RewItemCount2, RewItemCount3, RewItemCount4, RewRepFaction1,
RewRepFaction2, RewRepFaction3, RewRepFaction4, RewRepFaction5, RewRepValue1, RewRepValue2, RewRepValue3, RewRepValue4,
RewRepValue5, RewOrReqMoney, RewMoneyMaxLevel, RewSpell, RewSpellCast, RewMailTemplateId, RewMailMoney, RewMailDelaySecs,
PointMapId, PointX, PointY, PointOpt, DetailsEmote1, DetailsEmote2, DetailsEmote3, DetailsEmote4, DetailsEmoteDelay1,
DetailsEmoteDelay2, DetailsEmoteDelay3, DetailsEmoteDelay4, IncompleteEmote, CompleteEmote, OfferRewardEmote1, OfferRewardEmote2,
OfferRewardEmote3, OfferRewardEmote4, OfferRewardEmoteDelay1, OfferRewardEmoteDelay2, OfferRewardEmoteDelay3,OfferRewardEmoteDelay4,
StartScript, CompleteScript)
         values
 ('60148', '0', '2', '154', '4', '5', '0', '0', '0', '0', '0',
'0', '0', '0', '0', '0','0',
'0', '0', '0', '0', '0', '376', '0', '0', '0',
'0', '0', '0', 'Mother of the Hollow', 'We keep killing the spiders but we find that the number hasn\'t changed the next day. I think there\'s something off.\n\nGo down into the hollow and investigate. Come back in one piece and be rewarded.\n\nWe suspect that they have a broodmother.', 'Executor Arren wants you to investigate the Night Web Hollow and kill their broodmother.', 'Splendid!\n\nNow that the broodmother has been ridden of whe can finally cleaning out the mines for good.', 'They keep coming back, something is amiss.', '', '', '',
'', '', '0', '0', '0', '0', '0', '0', '0',
'0', '0', '0', '0', '0', '0', '0', '0',
'0', '1688', '0', '0', '0', '1',
'0', '0', '0', '0', '0', '0',
'0', '51885', '51886', '0', '0', '0', '0',
'1', '1', '0', '0', '0', '0',
'0', '0', '0', '0', '0', '0', '0', '0', '68',
'0', '0', '0', '0', '100', '0', '0', '0',
'0', '0', '200', '0', '0', '0', '0', '0',
'0', '0', '0', '0', '0', '0', '0', '0', '0',
'0', '0', '0', '0', '0', '0', '0',
'0', '0', '0', '0', '0','0',
0, 0);
replace into creature_questrelation (id, quest, patch_min, patch_max) values ('1570','60148','10','10');
replace into creature_involvedrelation (id, quest, patch_min, patch_max) values ('1570','60148','10','10');
      
update quest_template set PrevQuestId = 380 where entry = 60148;

update creature_template set scale = 2 where entry = 1688;
update creature_template set health_min = 150, health_max = 200, armor = 200 where entry = 1688;

 replace into item_template values
 ('51885', '0', '4', '1', 'Web Covered Shoes', '', '16576', '1', '0', '1', '18', '18', '8', '-1', '-1', '9',
 '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0',
 '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0',
 '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '13', '0', '0', '0',
 '0', '0', '0', '0', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0', '-1', '0', '0',
 '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0',
 '-1', '1', '0', '0', '0', '0', '0', '7', '0', '0', '0', '20', '0', '0', '0', '0', '0', '0', '0', '0',
 '0', '1', NULL);
 
 replace into item_template values
 ('51886', '0', '4', '3', 'Deathguard Boots', '', '22673', '1', '0', '1', '18', '18', '8', '-1', '-1', '9',
 '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0',
 '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0',
 '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '65', '0', '0', '0',
 '0', '0', '0', '0', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0', '-1', '0', '0',
 '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0',
 '-1', '1', '0', '0', '0', '0', '0', '5', '0', '0', '0', '30', '0', '0', '0', '0', '0', '0', '0', '0',
 '0', '1', NULL);
 
-- Mulgore

replace into quest_template (
entry, patch, Method, ZoneOrSort, MinLevel, QuestLevel, MaxLevel, Type, RequiredClasses, RequiredRaces, RequiredSkill,
RequiredSkillValue, RepObjectiveFaction, RepObjectiveValue, RequiredMinRepFaction, RequiredMinRepValue,RequiredMaxRepFaction,
RequiredMaxRepValue, SuggestedPlayers, LimitTime, QuestFlags, SpecialFlags, PrevQuestId, NextQuestId, ExclusiveGroup, NextQuestInChain,
SrcItemId, SrcItemCount, SrcSpell, Title, Details, Objectives, OfferRewardText, RequestItemsText, EndText, ObjectiveText1, ObjectiveText2,
ObjectiveText3, ObjectiveText4, ReqItemId1, ReqItemId2, ReqItemId3, ReqItemId4, ReqItemCount1, ReqItemCount2, ReqItemCount3,
ReqItemCount4, ReqSourceId1, ReqSourceId2, ReqSourceId3, ReqSourceId4, ReqSourceCount1, ReqSourceCount2, ReqSourceCount3,
ReqSourceCount4, ReqCreatureOrGOId1, ReqCreatureOrGOId2, ReqCreatureOrGOId3, ReqCreatureOrGOId4, ReqCreatureOrGOCount1,
ReqCreatureOrGOCount2, ReqCreatureOrGOCount3, ReqCreatureOrGOCount4, ReqSpellCast1, ReqSpellCast2, ReqSpellCast3,
ReqSpellCast4, RewChoiceItemId1, RewChoiceItemId2, RewChoiceItemId3, RewChoiceItemId4, RewChoiceItemId5, RewChoiceItemId6,
RewChoiceItemCount1, RewChoiceItemCount2, RewChoiceItemCount3, RewChoiceItemCount4, RewChoiceItemCount5, RewChoiceItemCount6,
RewItemId1, RewItemId2, RewItemId3, RewItemId4, RewItemCount1, RewItemCount2, RewItemCount3, RewItemCount4, RewRepFaction1,
RewRepFaction2, RewRepFaction3, RewRepFaction4, RewRepFaction5, RewRepValue1, RewRepValue2, RewRepValue3, RewRepValue4,
RewRepValue5, RewOrReqMoney, RewMoneyMaxLevel, RewSpell, RewSpellCast, RewMailTemplateId, RewMailMoney, RewMailDelaySecs,
PointMapId, PointX, PointY, PointOpt, DetailsEmote1, DetailsEmote2, DetailsEmote3, DetailsEmote4, DetailsEmoteDelay1,
DetailsEmoteDelay2, DetailsEmoteDelay3, DetailsEmoteDelay4, IncompleteEmote, CompleteEmote, OfferRewardEmote1, OfferRewardEmote2,
OfferRewardEmote3, OfferRewardEmote4, OfferRewardEmoteDelay1, OfferRewardEmoteDelay2, OfferRewardEmoteDelay3,OfferRewardEmoteDelay4,
StartScript, CompleteScript)
         values
 ('60150', '0', '2', '215', '3', '4', '60', '0', '0', '0', '0',
'0', '0', '0', '0', '0','0',
'0', '0', '0', '0', '0', '750', '0', '0', '0',
'0', '0', '0', 'Bristleback Aggression', 'The quilboar activity in the Brambleblade Valley has been increasing lately, we suspect that they\'re preparing for an attack on Camp Narache.\n\nGo to the ravine and thin their numbers, they fight without honor and deserve none.', 'Grull Hawkwind in Camp Narache wants you to kill 6 Bristleback Quilboars and 4 Bristleback Shamans.', 'With heroes like you we might even push them out of Mulgore.\n\nTake one, it\'s the least we can do.', 'Show them that we are not to be meddled with.', '', '', '',
'', '', '0', '0', '0', '0', '0', '0', '0',
'0', '0', '0', '0', '0', '0', '0', '0',
'0', '2952', '2953', '0', '0', '6',
'4', '0', '0', '0', '0', '0',
'0', '51887', '51888', '0', '0', '0', '0',
'1', '1', '0', '0', '0', '0',
'0', '0', '0', '0', '0', '0', '0', '0', '81',
'0', '0', '0', '0', '100', '0', '0', '0',
'0', '0', '200', '0', '0', '0', '0', '0',
'0', '0', '0', '0', '0', '0', '0', '0', '0',
'0', '0', '0', '0', '0', '0', '0',
'0', '0', '0', '0', '0','0',
0, 0);
replace into creature_questrelation (id, quest, patch_min, patch_max) values ('2980','60150','10','10');
replace into creature_involvedrelation (id, quest, patch_min, patch_max) values ('2980','60150','10','10');
      
 
 replace into item_template (
entry, patch, class, subclass, name,description, display_id, quality, flags, buy_count,
buy_price, sell_price, inventory_type, allowable_class, allowable_race, item_level,
required_level, required_skill, required_skill_rank, required_spell, required_honor_rank,
required_city_rank, required_reputation_faction, required_reputation_rank, max_count, stackable,
container_slots, stat_type1, stat_value1, stat_type2, stat_value2, stat_type3, stat_value3,
stat_type4, stat_value4, stat_type5, stat_value5, stat_type6, stat_value6, stat_type7,
stat_value7, stat_type8, stat_value8, stat_type9, stat_value9, stat_type10, stat_value10,
delay, range_mod, ammo_type, dmg_min1, dmg_max1, dmg_type1, dmg_min2, dmg_max2, dmg_type2,
dmg_min3, dmg_max3, dmg_type3, dmg_min4, dmg_max4, dmg_type4, dmg_min5, dmg_max5, dmg_type5, block,
armor, holy_res, fire_res, nature_res, frost_res, shadow_res, arcane_res, spellid_1, spelltrigger_1,
spellcharges_1, spellppmrate_1, spellcooldown_1, spellcategory_1, spellcategorycooldown_1, spellid_2,
spelltrigger_2, spellcharges_2, spellppmrate_2, spellcooldown_2, spellcategory_2, spellcategorycooldown_2,
spellid_3, spelltrigger_3, spellcharges_3, spellppmrate_3, spellcooldown_3, spellcategory_3,
spellcategorycooldown_3, spellid_4, spelltrigger_4, spellcharges_4, spellppmrate_4, spellcooldown_4,
spellcategory_4, spellcategorycooldown_4, spellid_5, spelltrigger_5, spellcharges_5, spellppmrate_5,
spellcooldown_5, spellcategory_5, spellcategorycooldown_5, bonding, page_text, page_language, page_material,
start_quest, lock_id, material, sheath, random_property, set_id, max_durability, area_bound, map_bound,
duration, bag_family, disenchant_id, food_type, min_money_loot, max_money_loot, extra_flags, other_team_entry,
script_name)
values
 ('51887', '0', '4', '2', 'Nomadic Pants', '', '12402', '1', '0', '1', '11', '11', '7', '-1', '-1', '5',
 '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0',
 '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0',
 '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '29', '0', '0', '0',
 '0', '0', '0', '0', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0', '-1', '0', '0',
 '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0',
 '-1', '1', '0', '0', '0', '0', '0', '8', '0', '0', '0', '35', '0', '0', '0', '0', '0', '0', '0', '0',
 '0', '1', NULL);
 
 replace into item_template (
entry, patch, class, subclass, name,description, display_id, quality, flags, buy_count,
buy_price, sell_price, inventory_type, allowable_class, allowable_race, item_level,
required_level, required_skill, required_skill_rank, required_spell, required_honor_rank,
required_city_rank, required_reputation_faction, required_reputation_rank, max_count, stackable,
container_slots, stat_type1, stat_value1, stat_type2, stat_value2, stat_type3, stat_value3,
stat_type4, stat_value4, stat_type5, stat_value5, stat_type6, stat_value6, stat_type7,
stat_value7, stat_type8, stat_value8, stat_type9, stat_value9, stat_type10, stat_value10,
delay, range_mod, ammo_type, dmg_min1, dmg_max1, dmg_type1, dmg_min2, dmg_max2, dmg_type2,
dmg_min3, dmg_max3, dmg_type3, dmg_min4, dmg_max4, dmg_type4, dmg_min5, dmg_max5, dmg_type5, block,
armor, holy_res, fire_res, nature_res, frost_res, shadow_res, arcane_res, spellid_1, spelltrigger_1,
spellcharges_1, spellppmrate_1, spellcooldown_1, spellcategory_1, spellcategorycooldown_1, spellid_2,
spelltrigger_2, spellcharges_2, spellppmrate_2, spellcooldown_2, spellcategory_2, spellcategorycooldown_2,
spellid_3, spelltrigger_3, spellcharges_3, spellppmrate_3, spellcooldown_3, spellcategory_3,
spellcategorycooldown_3, spellid_4, spelltrigger_4, spellcharges_4, spellppmrate_4, spellcooldown_4,
spellcategory_4, spellcategorycooldown_4, spellid_5, spelltrigger_5, spellcharges_5, spellppmrate_5,
spellcooldown_5, spellcategory_5, spellcategorycooldown_5, bonding, page_text, page_language, page_material,
start_quest, lock_id, material, sheath, random_property, set_id, max_durability, area_bound, map_bound,
duration, bag_family, disenchant_id, food_type, min_money_loot, max_money_loot, extra_flags, other_team_entry,
script_name)
values
 ('51888', '0', '4', '3', 'Painted Chain Boots', '', '22684', '1', '0', '1', '11', '11', '8', '-1', '-1', '5',
 '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0',
 '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0',
 '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '46', '0', '0', '0',
 '0', '0', '0', '0', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0', '-1', '0', '0',
 '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0',
 '-1', '1', '0', '0', '0', '0', '0', '5', '0', '0', '0', '25', '0', '0', '0', '0', '0', '0', '0', '0',
 '0', '1', NULL);
 
 -- Nefr garden shovel
 
 UPDATE `item_template` SET `spellid_1`='0', `spelltrigger_1`='0' WHERE (`entry`='51719') AND (`patch`='0');
 
 update item_template set name = "Sickly Gazelle Flesh Sample", stackable = 10 where entry = 51860;

 -- Plagued Hatchling pet
replace into item_template (
entry, patch, class, subclass, name,description, display_id, quality, flags, buy_count,
buy_price, sell_price, inventory_type, allowable_class, allowable_race, item_level,
required_level, required_skill, required_skill_rank, required_spell, required_honor_rank,
required_city_rank, required_reputation_faction, required_reputation_rank, max_count, stackable,
container_slots, stat_type1, stat_value1, stat_type2, stat_value2, stat_type3, stat_value3,
stat_type4, stat_value4, stat_type5, stat_value5, stat_type6, stat_value6, stat_type7,
stat_value7, stat_type8, stat_value8, stat_type9, stat_value9, stat_type10, stat_value10,
delay, range_mod, ammo_type, dmg_min1, dmg_max1, dmg_type1, dmg_min2, dmg_max2, dmg_type2,
dmg_min3, dmg_max3, dmg_type3, dmg_min4, dmg_max4, dmg_type4, dmg_min5, dmg_max5, dmg_type5, block,
armor, holy_res, fire_res, nature_res, frost_res, shadow_res, arcane_res, spellid_1, spelltrigger_1,
spellcharges_1, spellppmrate_1, spellcooldown_1, spellcategory_1, spellcategorycooldown_1, spellid_2,
spelltrigger_2, spellcharges_2, spellppmrate_2, spellcooldown_2, spellcategory_2, spellcategorycooldown_2,
spellid_3, spelltrigger_3, spellcharges_3, spellppmrate_3, spellcooldown_3, spellcategory_3,
spellcategorycooldown_3, spellid_4, spelltrigger_4, spellcharges_4, spellppmrate_4, spellcooldown_4,
spellcategory_4, spellcategorycooldown_4, spellid_5, spelltrigger_5, spellcharges_5, spellppmrate_5,
spellcooldown_5, spellcategory_5, spellcategorycooldown_5, bonding, page_text, page_language, page_material,
start_quest, lock_id, material, sheath, random_property, set_id, max_durability, area_bound, map_bound,
duration, bag_family, disenchant_id, food_type, min_money_loot, max_money_loot, extra_flags, other_team_entry,
script_name)
values
 ('51858', '0', '15', '0', 'Plagued Hatchling', '', '23725', '2', '0', '1', '0', '0', '4', '-1', '-1', '0',
 '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0',
 '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0',
 '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0',
 '0', '1', '0', '28505', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0', '-1', '0', '0',
 '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0',
 '-1', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0',
 '0', '1', NULL);
 update item_template set shadow_res = 0, inventory_type = 0 where entry = 51858;
REPLACE INTO `creature_template` VALUES (51585,0,10007,0,0,0,'Plagued Hatchling','',0,1,1,64,64,0,0,0,35,0,1,1.14286,0.75,20,5,0,0,1,0,0,0,0,1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'',0,3,0,0,3,0,0,0,0,0,0,'');
replace into custom_pet_entry_relation (item_entry, creature_entry) values (51858, 51585);

update battleground_template set min_players_per_team = 5 where max_players_per_team = 40;

-- Misc. fixes:

update item_template set display_id = 27062 where entry = 51757;

-- Open House Rewards

REPLACE INTO `item_template` VALUES (51892, 0, 15, 0, 'Open House Gift Box', '', 16028, 1, 4, 1, 0, 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, -1, 0, -1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, NULL);

replace into item_template values
 ('51890', '0', '4', '0', 'Adventurer\'s Shirt', 'Turtle WoW Open House 2020.', '18466', '3', '0', '1', '0', '0', '4', '-1', '-1', '15',
 '0', '0', '0', '0', '0', '0', '0', '0', '1', '1', '0', '0', '0', '0', '0',
 '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0',
 '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0',
 '0', '0', '0', '0', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0', '-1', '0', '0',
 '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '0', '-1', '0',
 '-1', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0',
 '0', '1', NULL);
 
replace into item_template (entry, class, subclass, name, description, display_id, quality, bonding, spellid_1, spellcooldown_1) values
(51891, 15, 2, 'Mysterious Fortune Teller', 'Extremely trustworthy individual.', 940, 3, 1, 28505, 1500);
replace into creature_template (entry, display_id1, display_id2, display_id3, name, subname, level_min, level_max, health_min, health_max, faction, script_name, scale) values
('51605', '491', '0', '0', 'Ro\'Paw', '', '1', '1', '64', '64', '35', 'npc_ropaw', 0.7);
update creature_template set equipment_id = 14822 where entry = 51605;
update creature_template set npc_flags = 1 where entry = 51605;
replace into custom_pet_entry_relation (item_entry, creature_entry) values 
('51891', '51605'); 

update item_template set bonding = 6 where entry in (51890, 51891);
 
REPLACE INTO `item_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `groupid`, `mincountOrRef`, `maxcount`, `condition_id`, `patch_min`, `patch_max`) VALUES 

(51892, 51890, 100, 1, 1, 1, 0, 0, 10),   
(51892, 51891, 100, 2, 1, 1, 0, 0, 10);

replace into broadcast_text (ID, MaleText) values 
(90560, 'Never eat beef with a tauren.'),
(90561, 'You will find something wonderful tomorrow.'),
(90562, 'An enemy from your past will soon become an ally.'),
(90563, 'You will be fortunate in everything you put your hands to.'),
(90564, 'Someone is speaking well of you.'),
(90565, 'Be cautious when landing in unfamiliar territory.'),
(90566, 'Avoid taking unnecessary gambles.'),
(90567, 'You will receive a fortune.'),
(90568, 'Your first love and last love is self-love.'),
(90569, 'Rest is a good thing, but boredom is its brother.'),
(90570, 'Those with simple tastes are always satisfied with the best.'),
(90571, 'Let not the tides of war wash you away.'),
(90572, 'You leave your adversaries speechless.'),
(90573, 'You have a good eye for spotting hypocrisy.'),
(90574, 'One learns most when teaching others.'),
(90575, 'The time will soon come for you to make a choice in a pressing matter.'),
(90576, 'Never punt a gnome without due cause.'),
(90577, 'Accept the next proposition you hear.'),
(90578, 'The Forsaken are up to something.'),
(90579, 'Many a false step is made by standing still.'),
(90580, 'Divine Shields and Hearthstones do not make a hero heroic.'),
(90581, 'An answer in blue is always true.'),
(90582, 'Your fortune awaits you in Molten Core.'),
(90583, 'Hunters who specialize in survival are not guaranteed to survive.'),
(90584, 'A Shaman\'s blessing is elementary.'),
(90585, 'The sun will shine tomorrow.'),
(90586, 'All of the effort you are making is worth the repair costs.'),
(90587, 'As the purse is emptied, the rogue\'s heart fills.'),
(90588, 'Trust in the Light, but watch your mount.'),
(90589, 'You will develop a great sense of relaxation and patience from the fishing profession.'),
(90590, 'You aren\'t very lucky.  Yet.'),
(90591, 'He who expects a wipe will never be disappointed.'),
(90592, 'A friend asks for your time. A guild asks for your money.'),
(90593, 'Never stand in the shadow of dragons.'),
(90594, 'Someone nearby wants to /flirt with you.'),
(90595, 'A light heart carries you through bad Battlegrounds.'),
(90596, 'Your future is clouded with a purple rain.'),
(90597, 'Never trust a troll. Or a rogue. Especially a troll rogue.'),
(90598, 'Now is the time to try something new. Perhaps a new tradeskill.'),
(90599, 'Your lucky numbers are: 4 8 15 16 23 42'),
(90600, 'When life gives you lemons, pay for repair costs.'),
(90601, 'Every herb blooms in its own sweet time. Then you pick it!'),
(90602, 'The road to Blackrock Mountain is paved with good intentions.'),
(90603, 'You will live a long, happy life with many resurrections along the way.'),
(90604, 'Go take a rest. You deserve it. Remember to rest in an inn though!'),
(90605, 'You really should\'ve looted that spider.'),
(90606, 'You will inherit a large sum of money. You will blow it at the Auction House.'),
(90607, 'The path of the faceroller is not the path to wisdom.'),
(90608, 'Many raid wipes are in your immediate future.'),
(90609, 'He who fights an army is a martyr; he who fights five is elite.'),
(90610, 'You\'ll never know until you loot.'),
(90611, 'You will hear the tinkling of golden coins.'),
(90612, 'Your racial leader is thinking about you.'),
(90613, 'You will someday be able to afford that mount.'),
(90614, 'Stay away from mystery meat.'),
(90615, 'Never trust an honest goblin or a sober dwarf.'),
(90616, 'The future looks cataclysmic.'),
(90617, 'Beware of a tall night elf with one blond boot.'),
(90618, 'Be cautious in your daily quests.'),
(90619, 'Find beauty in ordinary things. Vendor them for cash.'),
(90620, 'Epics are like children; none are so wonderful as your own.'),
(90621, 'One who promises to go on a blind date is bound on pickup.'),
(90622, 'If I were you, I wouldn\'t get on boats anytime soon.'),
(90623, 'Your outlook looks bright, unless you run into Xerron.'),
(90624, 'You might have better luck with another fortune.'),
(90625, 'You have a good chance to roll 100 in the near future.'),
(90626, 'Disbelief destroys the magic.'),
(90627, 'The beginning of wisdom is to desire it. The end of wisdom is to theorycraft.'),
(90628, 'You will receive a gift from someone you hate.');

replace into broadcast_text (ID, MaleText) values (90650, 'Greetings, $N. Care to hear your fortune?'); replace into npc_text (ID, BroadcastTextID0) values (90650, 90650);
replace into broadcast_text (ID, MaleText) values (90651, 'Back for another reading?'); replace into npc_text (ID, BroadcastTextID0) values (90651, 90651);
replace into broadcast_text (ID, MaleText) values (90652, 'I have some bad news for you. Want me to share?'); replace into npc_text (ID, BroadcastTextID0) values (90652, 90652);
replace into broadcast_text (ID, MaleText) values (90653, 'If I were you, I wouldn\'t wear blue today.'); replace into npc_text (ID, BroadcastTextID0) values (90653, 90653);
replace into broadcast_text (ID, MaleText) values (90654, 'Eight is my lucky number. Always bet on the number eight.'); replace into npc_text (ID, BroadcastTextID0) values (90654, 90654);
replace into broadcast_text (ID, MaleText) values (90655, 'Let me read your paw. Oh, my. That can\'t be good.'); replace into npc_text (ID, BroadcastTextID0) values (90655, 90655);
replace into broadcast_text (ID, MaleText) values (90656, 'I\'ve seen a lot of bad fortunes, but your\'s is the worst!'); replace into npc_text (ID, BroadcastTextID0) values (90656, 90656);
replace into broadcast_text (ID, MaleText) values (90657, 'It looks like I might be looking for a new traveling companion soon.'); replace into npc_text (ID, BroadcastTextID0) values (90657, 90657);
replace into broadcast_text (ID, MaleText) values (90658, 'How\'s your day going? Just kidding, I already know.'); replace into npc_text (ID, BroadcastTextID0) values (90658, 90658);
replace into broadcast_text (ID, MaleText) values (90659, 'Don\'t eat the red mushroom you find off the ground. You\'ll thank me later.'); replace into npc_text (ID, BroadcastTextID0) values (90659, 90659);
replace into broadcast_text (ID, MaleText) values (90660, 'You will find true love one day. But then you\'ll forget where you put it.'); replace into npc_text (ID, BroadcastTextID0) values (90660, 90660);
replace into broadcast_text (ID, MaleText) values (90661, 'I hope you don\'t mind prison food.'); replace into npc_text (ID, BroadcastTextID0) values (90661, 90661);
replace into broadcast_text (ID, MaleText) values (90662, 'Don\'t buy any potions from that goblin alchemist you\'ll meet today.'); replace into npc_text (ID, BroadcastTextID0) values (90662, 90662);
replace into broadcast_text (ID, MaleText) values (90663, 'Please don\'t run into that group of ogres today. You\'ll break every bone in your body.'); replace into npc_text (ID, BroadcastTextID0) values (90663, 90663);
replace into broadcast_text (ID, MaleText) values (90664, 'Wanna know how long you have left to live?'); replace into npc_text (ID, BroadcastTextID0) values (90664, 90664);
replace into broadcast_text (ID, MaleText) values (90665, 'Beware of an orc with a silly sounding name starting with the letter K. He\'s up to no good.'); replace into npc_text (ID, BroadcastTextID0) values (90665, 90665);
replace into broadcast_text (ID, MaleText) values (90666, 'You should check the auction house right now for some unbelievable deals.'); replace into npc_text (ID, BroadcastTextID0) values (90666, 90666);
replace into broadcast_text (ID, MaleText) values (90667, 'I hope you know how to swim.'); replace into npc_text (ID, BroadcastTextID0) values (90667, 90667);
 
 -- Misc. fixes:
 
 update item_template set max_durability = 75 where entry = 51820;
 update item_template set inventory_type = 26 where entry = 51820;
 
 -- Mount fixes
 
 update item_template set required_level = 0 where entry in (50071,50072,50073,50076,50074,12325,12326,8630,13325,5875,5874,1041,8590);
 update item_template set required_level = 0 where entry in (13329,12353,12302,12303,12351,15293,18768,23193,50399,50400,50401,50402,50403,50404,50407);
 
  update item_template set required_skill = 0, required_skill_rank = 0 where entry in (50071,50072,50073,50076,50074,12325,12326,8630,13325,5875,5874,1041,8590);
 update item_template set required_skill = 0, required_skill_rank = 0 where entry in (13329,12353,12302,12303,12351,15293,18768,23193,50399,50400,50401,50402,50403,50404,50407);
 
  update item_template set quality = 3 where entry in (50071,50072,50073,50076,50074,12325,12326,8630,13325,5875,5874,1041,8590);
 update item_template set quality = 3 where entry in (13329,12353,12302,12303,12351,15293,18768,23193,50399,50400,50401,50402,50403,50404,50407);
 
 -- Wormhole fixes
 
 update item_template set script_name = "item_test_wormhole_generator", description = "Creates a highly radioactive Wormhole, lasting 5 seconds. 1 charge." where entry = 51808;
 
 -- Fix Mazoga text
 
 replace into broadcast_text (ID, MaleText) values ('90501', 'I’m a free knight! I don’t have a lord. You got a problem with that?\n\nAh whatever... Welcome to our chapel! I can give you a sleeping bag or offer you some rations.');
 
 -- Loot issues
 
REPLACE INTO `creature_loot_template` VALUES (10429, 12588, 17, 0, 1, 1, 0, 0, 10);

-- Geddon

REPLACE INTO `creature_loot_template` VALUES (12056, 4787, 40, 0, 1, 5, 0, 0, 10);
REPLACE INTO `creature_loot_template` VALUES (12056, 7068, 30, 0, 1, 6, 0, 0, 10);
REPLACE INTO `creature_loot_template` VALUES (12056, 7077, 30, 0, 1, 3, 0, 0, 10);
REPLACE INTO `creature_loot_template` VALUES (12056, 7078, 50, 0, 1, 2, 0, 0, 10);
REPLACE INTO `creature_loot_template` VALUES (12056, 17010, 3, 0, 1, 1, 0, 0, 10); -- -7
REPLACE INTO `creature_loot_template` VALUES (12056, 18563, 14, 0, 1, 1, 0, 0, 10); -- +7
REPLACE INTO `creature_loot_template` VALUES (12056, 20951, -1, 0, 1, 1, 0, 0, 10);
REPLACE INTO `creature_loot_template` VALUES (12056, 30001, 10, 0, -30001, 1, 0, 2, 10);
REPLACE INTO `creature_loot_template` VALUES (12056, 30349, 100, 0, -30349, 1, 0, 0, 10);
REPLACE INTO `creature_loot_template` VALUES (12056, 30350, 100, 0, -30350, 1, 0, 0, 10);
REPLACE INTO `creature_loot_template` VALUES (12056, 30351, 100, 0, -30351, 1, 0, 0, 10);

delete from creature_questrelation where id = 16547;

-- Anub


DELETE FROM `script_texts` WHERE `entry` IN (-1533000, -1533001, -1533002, -1533003, -1533004, -1533005, -1533006, -1533007,
                                             -1533008, -1000003, -1533010, -1533011, -1533012, -1533013, -1533014, -1533015,
                                             -1533016, -1533044, -1533045, -1533046, -1533047, -1533048, -1533049, -1533050,
                                             -1533065, -1533066, -1533067, -1533068, -1533069, -1533070, -1533071, -1533072,
                                             -1533073, -1533074, -1533155, -1533154, -1533153, -1533051, -1533052, -1533053,
                                             -1533054, -1533055, -1533056, -1533057, -1533058, -1533059, -1533060, -1533061,
                                             -1533062, -1533063, -1533064, -1533119, -1533152, -1533040, -1533140, -1533141,
                                             -1533142, -1533041, -1533042, -1533043, -1533109, -1533110, -1533111, -1533112,
                                             -1533113, -1533114, -1533115, -1533117, -1533116, -1533105, -1533135, -1533094,
                                             -1533095, -1533096, -1533097, -1533098, -1533099, -1533100, -1533101, -1533102,
                                             -1533103, -1533104, -1533143, -1533145, -1533144, -1533146, -1533147, -1533148,
                                             -1533130, -1533131, -1533132, -1533133, -1533075, -1533076, -1533077, -1533078,
                                             -1533079, -1533080, -1533081, -1533017, -1533018, -1533019, -1533020, -1533021,
                                             -1533022, -1533120, -1533121, -1533122, -1533123, -1533124, -1533125, -1533126,
                                             -1533127, -1533128, -1533129, -1533159, -1533082, -1533083, -1533023, -1533024,
                                             -1533025, -1533026, -1533027, -1533028, -1533151, -1533030, -1533031, -1533032,
                                             -1533033, -1533034, -1533035, -1533149, -1533150, -1533036, -1533037, -1533038,
                                             -1533039, -1533090, -1533091, -1533092, -1533093, -1533089, -1533084, -1533085,
                                             -1533086, -1533087, -1533088, -1533009, -1533029, -1533052, -1533061, -1533073,
                                             -1533047);

UPDATE `broadcast_text` SET `type` = 1, `sound` = 8788 WHERE `ID` = 13004;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8785 WHERE `ID` = 13000;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8786 WHERE `ID` = 13002;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8787 WHERE `ID` = 13003;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8790 WHERE `ID` = 13006;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8791 WHERE `ID` = 13007;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8792 WHERE `ID` = 13008;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8793 WHERE `ID` = 13009;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8789 WHERE `ID` = 13005;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8794 WHERE `ID` = 12856;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8795 WHERE `ID` = 12857;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8796 WHERE `ID` = 12858;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8797 WHERE `ID` = 12859;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8800 WHERE `ID` = 12854;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8801 WHERE `ID` = 12855;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8798 WHERE `ID` = 12853;
UPDATE `broadcast_text` SET `sound` = 8892 WHERE `ID` = 13010;
UPDATE `broadcast_text` SET `type` = 6, `sound` = 8896 WHERE `ID` = 13014;
UPDATE `broadcast_text` SET `type` = 6, `sound` = 8897 WHERE `ID` = 13015;
UPDATE `broadcast_text` SET `type` = 6, `sound` = 8898 WHERE `ID` = 13016;
UPDATE `broadcast_text` SET `sound` = 8895 WHERE `ID` = 13013;
UPDATE `broadcast_text` SET `sound` = 8894 WHERE `ID` = 13014;
UPDATE `broadcast_text` SET `sound` = 8893 WHERE `ID` = 13011;
UPDATE `broadcast_text` SET `sound` = 8835 WHERE `ID` = 13051;
UPDATE `broadcast_text` SET `sound` = 8836 WHERE `ID` = 13052;
UPDATE `broadcast_text` SET `sound` = 8837 WHERE `ID` = 13053;
UPDATE `broadcast_text` SET `sound` = 8839 WHERE `ID` = 13055;
UPDATE `broadcast_text` SET `sound` = 8840 WHERE `ID` = 13056;
UPDATE `broadcast_text` SET `sound` = 8841 WHERE `ID` = 13057;
UPDATE `broadcast_text` SET `sound` = 8842 WHERE `ID` = 13058;
UPDATE `broadcast_text` SET `sound` = 8843 WHERE `ID` = 13059;
UPDATE `broadcast_text` SET `type` = 6, `sound` = 8844 WHERE `ID` = 13060;
UPDATE `broadcast_text` SET `sound` = 8838 WHERE `ID` = 13054;
UPDATE `broadcast_text` SET `sound` = 8899 WHERE `ID` = 13034;
UPDATE `broadcast_text` SET `type` = 6, `sound` = 8903 WHERE `ID` = 13038;
UPDATE `broadcast_text` SET `type` = 6, `sound` = 8904 WHERE `ID` = 13039;
UPDATE `broadcast_text` SET `sound` = 8905 WHERE `ID` = 13040;
UPDATE `broadcast_text` SET `sound` = 8902 WHERE `ID` = 13037;
UPDATE `broadcast_text` SET `sound` = 8901 WHERE `ID` = 13036;
UPDATE `broadcast_text` SET `sound` = 8900 WHERE `ID` = 13035;
UPDATE `broadcast_text` SET `sound` = 8913 WHERE `ID` = 13097;
UPDATE `broadcast_text` SET `type` = 6, `sound` = 8917 WHERE `ID` = 13101;
UPDATE `broadcast_text` SET `type` = 6, `sound` = 8918 WHERE `ID` = 13102;
UPDATE `broadcast_text` SET `type` = 6, `sound` = 8919 WHERE `ID` = 13103;
UPDATE `broadcast_text` SET `sound` = 8916 WHERE `ID` = 13100;
UPDATE `broadcast_text` SET `sound` = 8915 WHERE `ID` = 13099;
UPDATE `broadcast_text` SET `sound` = 8914 WHERE `ID` = 13098;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8807 WHERE `ID` = 13029;
UPDATE `broadcast_text` SET `type` = 1 WHERE `ID` = 13031;
UPDATE `broadcast_text` SET `type` = 1 WHERE `ID` = 13032;
UPDATE `broadcast_text` SET `type` = 1 WHERE `ID` = 13033;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8806 WHERE `ID` = 13027;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8805 WHERE `ID` = 13026;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8808 WHERE `ID` = 13028;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8825 WHERE `ID` = 13041;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8826 WHERE `ID` = 13042;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8827 WHERE `ID` = 13043;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8829 WHERE `ID` = 13045;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8830 WHERE `ID` = 13046;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8831 WHERE `ID` = 13047;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8832 WHERE `ID` = 13048;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8834 WHERE `ID` = 13050;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8833 WHERE `ID` = 13049;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8819 WHERE `ID` = 12999;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8809 WHERE `ID` = 12995;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8810 WHERE `ID` = 12996;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8811 WHERE `ID` = 12997;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8817 WHERE `ID` = 13021;
UPDATE `broadcast_text` SET `sound` = 8818 WHERE `ID` = 13022;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8814 WHERE `ID` = 13019;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8812 WHERE `ID` = 13017;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8813 WHERE `ID` = 13018;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8815 WHERE `ID` = 13020;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8816 WHERE `ID` = 12998;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8824 WHERE `ID` = 12994;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8845 WHERE `ID` = 13061;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8846 WHERE `ID` = 13062;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8847 WHERE `ID` = 13063;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8851 WHERE `ID` = 13067;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8849 WHERE `ID` = 13065;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8850 WHERE `ID` = 13066;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8848 WHERE `ID` = 13064;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8909 WHERE `ID` = 13068;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8910 WHERE `ID` = 13069;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8912 WHERE `ID` = 13071;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8911 WHERE `ID` = 13070;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8852 WHERE `ID` = 13072;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8853 WHERE `ID` = 13073;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8854 WHERE `ID` = 13074;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8861 WHERE `ID` = 13080;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8862 WHERE `ID` = 13081;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8855 WHERE `ID` = 13075;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8856 WHERE `ID` = 13076;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8858 WHERE `ID` = 13077;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8859 WHERE `ID` = 13078;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8860 WHERE `ID` = 13079;
UPDATE `broadcast_text` SET `type` = 3 WHERE `ID` = 13082;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8864 WHERE `ID` = 13083;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8866 WHERE `ID` = 13085;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8865 WHERE `ID` = 13084;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8802 WHERE `ID` = 13023;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8804 WHERE `ID` = 13025;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8803 WHERE `ID` = 13024;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8867 WHERE `ID` = 13086;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8868 WHERE `ID` = 13087;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8869 WHERE `ID` = 13088;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8877 WHERE `ID` = 13096;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8871 WHERE `ID` = 13090;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8870 WHERE `ID` = 13089;
UPDATE `broadcast_text` SET `type` = 3 WHERE `ID` = 12156;
UPDATE `broadcast_text` SET `type` = 3 WHERE `ID` = 12178;
UPDATE `broadcast_text` SET `type` = 6, `sound` = 8873 WHERE `ID` = 13092;
UPDATE `broadcast_text` SET `type` = 6, `sound` = 8874 WHERE `ID` = 13093;
UPDATE `broadcast_text` SET `type` = 6, `sound` = 8875 WHERE `ID` = 13094;
UPDATE `broadcast_text` SET `type` = 6, `sound` = 8876 WHERE `ID` = 13095;
UPDATE `broadcast_text` SET `type` = 6, `sound` = 8820 WHERE `ID` = 12984;
UPDATE `broadcast_text` SET `type` = 6, `sound` = 8821 WHERE `ID` = 12985;
UPDATE `broadcast_text` SET `type` = 6, `sound` = 8822 WHERE `ID` = 12986;
UPDATE `broadcast_text` SET `type` = 6, `sound` = 8823 WHERE `ID` = 12987;
UPDATE `broadcast_text` SET `type` = 6 WHERE `ID` = 13150;
UPDATE `broadcast_text` SET `type` = 6, `sound` = 8878 WHERE `ID` = 12990;
UPDATE `broadcast_text` SET `type` = 6, `sound` = 8881 WHERE `ID` = 12988;
UPDATE `broadcast_text` SET `type` = 6, `sound` = 8879 WHERE `ID` = 12991;
UPDATE `broadcast_text` SET `type` = 6, `sound` = 8882 WHERE `ID` = 12989;
UPDATE `broadcast_text` SET `type` = 6, `sound` = 8880 WHERE `ID` = 12992;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8799 WHERE `ID` = 12852;
UPDATE `broadcast_text` SET `type` = 1, `sound` = 8872 WHERE `ID` = 13091;
 