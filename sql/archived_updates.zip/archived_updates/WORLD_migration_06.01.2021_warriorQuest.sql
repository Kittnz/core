INSERT INTO `creature_questrelation` (`id`, `quest`, `patch_min`, `patch_max`) VALUES ('5480', '1638', '0', '10');
